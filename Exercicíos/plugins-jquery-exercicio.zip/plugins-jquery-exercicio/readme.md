### Exercício Módulo 10 - Plugins jQuery

## Dicas

- O carousel slick utiliza a ID do campo para atribuir funções.
- A semântica de escrita do HTML e jQuery utilizam o idioma inglês.
- O jQuery plugin só executa depois que o jQuery carregar na página.